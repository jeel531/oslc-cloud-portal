@echo off
title OSLC Packing Control (Browser Launcher)
cd /d "%~dp0"

set "LAN_URL=http://192.168.100.106:8787"
set "CLOUD_URL=https://ordinary-angela-possess-thinks.trycloudflare.com"

if exist "server_url.txt" (
  set /p CUSTOM_URL=<server_url.txt
)
if exist "online_link.txt" (
  set /p LATEST_CLOUD=<online_link.txt
  if not "%LATEST_CLOUD%"=="" set "CLOUD_URL=%LATEST_CLOUD%"
)

echo Checking connection to OSLC Server...
powershell -NoProfile -Command "try { $r=Invoke-WebRequest -UseBasicParsing '%LAN_URL%/health' -TimeoutSec 2; if ($r.StatusCode -eq 200) { exit 0 } } catch {}; exit 1" >nul 2>&1
if not errorlevel 1 (
  set "TARGET_URL=%LAN_URL%"
  echo Connected to Local LAN: %LAN_URL%
) else (
  set "TARGET_URL=%CLOUD_URL%"
  echo Local LAN not reachable, using Online Cloud Link: %CLOUD_URL%
)

rem Find Chrome or Edge to launch in clean app window
set "CHROME=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not exist "%CHROME%" set "CHROME=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if not exist "%CHROME%" set "CHROME=%LocalAppData%\Google\Chrome\Application\chrome.exe"

set "EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE%" set "EDGE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"

if exist "%CHROME%" (
  start "" "%CHROME%" --app=%TARGET_URL%
) else if exist "%EDGE%" (
  start "" "%EDGE%" --app=%TARGET_URL%
) else (
  start "" "%TARGET_URL%"
)

exit
