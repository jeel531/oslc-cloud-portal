﻿$ErrorActionPreference = "Stop"
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$desktop = [Environment]::GetFolderPath("Desktop")
$shell = New-Object -ComObject WScript.Shell

$edge = Join-Path ${env:ProgramFiles(x86)} "Microsoft\Edge\Application\msedge.exe"
if (-not (Test-Path $edge)) { $edge = "C:\Program Files\Google\Chrome\Application\chrome.exe" }
$iconPath = Join-Path $scriptDir "OSLC_ERP.ico"

# 1. Cloud Live Shortcut (Works everywhere: Home & Office)
$cloudUrl = "http://oslcerp-live.surge.sh"
$cloudShortcut = $shell.CreateShortcut((Join-Path $desktop "OSLC ERP (Cloud Live).lnk"))
if (Test-Path $edge) {
    $cloudShortcut.TargetPath = $edge
    $cloudShortcut.Arguments = "--app=$cloudUrl"
} else {
    $cloudShortcut.TargetPath = $cloudUrl
}
if (Test-Path $iconPath) { $cloudShortcut.IconLocation = "$iconPath,0" }
$cloudShortcut.Description = "Open OSLC ERP Live (Anywhere)"
$cloudShortcut.Save()

# 2. Office Wi-Fi Shortcut (Ultra-fast inside Office)
$officeUrl = "http://192.168.100.106:8000/"
$officeShortcut = $shell.CreateShortcut((Join-Path $desktop "OSLC ERP (Office Wi-Fi).lnk"))
if (Test-Path $edge) {
    $officeShortcut.TargetPath = $edge
    $officeShortcut.Arguments = "--app=$officeUrl"
} else {
    $officeShortcut.TargetPath = $officeUrl
}
if (Test-Path $iconPath) { $officeShortcut.IconLocation = "$iconPath,0" }
$officeShortcut.Description = "Open OSLC ERP Office LAN"
$officeShortcut.Save()

Write-Host "========================================" -ForegroundColor Green
Write-Host " OSLC ERP DESKTOP SHORTCUTS CREATED!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host "1. 'OSLC ERP (Cloud Live)' -> Office ane bahar badhe j chalse!" -ForegroundColor Cyan
Write-Host "2. 'OSLC ERP (Office Wi-Fi)' -> Office Wi-Fi par full speed chalse!" -ForegroundColor Cyan
Write-Host ""
Start-Sleep -Seconds 3
