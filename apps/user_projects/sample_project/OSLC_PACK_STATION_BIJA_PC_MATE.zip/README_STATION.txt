OSLC PACK STATION CLIENT (BIJA PC MATE SETUP)
=============================================

Gujarati Instructions:
1. Aa aakho folder bija pack-station PC par copy karo (pen drive athva LAN share thi).
2. Tya SETUP_STATION.bat par double-click karo.
   (Aa automatically printer modules install karshe ane Desktop par 'OSLC Pack Station' no icon banavi deshe).
3. Jo server nu IP change thay, to server_url.txt file ma navu address lakhi save karo (default: http://192.168.100.126:8787).
4. Havethi packing karti vakhate fakt Desktop na 'OSLC Pack Station' icon par double-click karvanu!
   Print agent background ma chalu thai jashe ane dashboard browser ma direct open thai jashe!
