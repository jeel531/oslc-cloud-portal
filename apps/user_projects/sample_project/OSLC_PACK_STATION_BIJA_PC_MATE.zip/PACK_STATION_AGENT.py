import ctypes,io,json,os,re,subprocess,threading,urllib.parse,urllib.request,webbrowser
from ctypes import wintypes
from datetime import datetime
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path

import pymupdf as fitz
from PIL import Image
try:
    from PIL import ImageWin
except Exception:
    ImageWin = None


ROOT=Path(__file__).resolve().parent
CFG=ROOT/"pack_station_config.json"
OUT=ROOT/"LOCAL_PRINTED_PDF";OUT.mkdir(exist_ok=True)
DEFAULT={"mrp_printer":"TSC TE244","shipping_printer":"TSC DA310","retail_printer":"TSC TE244","mrp_width_mm":100.0,"mrp_height_mm":50.0,"shipping_width_mm":100.0,"shipping_height_mm":150.0}
AGENT_VERSION="V01.01.3"
PRINT_LOCK=threading.Lock()

def default_printer():
    try:
        import win32print
        dp = win32print.GetDefaultPrinter()
        if dp: return dp
    except Exception:
        pass
    p_list = printers()
    tsc = [p for p in p_list if "TSC" in p.upper()]
    if tsc: return tsc[0]
    return p_list[0] if p_list else ""

def config():
    if not CFG.exists(): CFG.write_text(json.dumps(DEFAULT,indent=2),encoding="utf-8")
    try: c = {**DEFAULT,**json.loads(CFG.read_text(encoding="utf-8"))}
    except: c = dict(DEFAULT)
    dp = default_printer()
    if not c.get("mrp_printer") and dp: c["mrp_printer"] = dp
    if not c.get("retail_printer") and dp: c["retail_printer"] = c.get("mrp_printer") or dp
    if not c.get("shipping_printer") and dp: c["shipping_printer"] = dp
    return c

def save_config(data):
    c=config()
    for k in ("mrp_printer","shipping_printer","retail_printer"):
        if k in data: c[k]=str(data[k] or "").strip()
    for k in ("mrp_width_mm","mrp_height_mm","shipping_width_mm","shipping_height_mm"):
        try: c[k]=max(10,min(500,float(data.get(k, c.get(k, DEFAULT[k])))))
        except: pass
    CFG.write_text(json.dumps(c,indent=2),encoding="utf-8")
    try:
        desk_cfg = Path(os.path.expanduser("~")) / "OneDrive" / "Desktop" / "pack_station_config.json"
        if not desk_cfg.exists(): desk_cfg = Path(os.path.expanduser("~")) / "Desktop" / "pack_station_config.json"
        if desk_cfg.parent.exists(): desk_cfg.write_text(json.dumps(c,indent=2),encoding="utf-8")
    except Exception:
        pass
    return c

def printers():
    try:
        import win32print
        return sorted({p[2] for p in win32print.EnumPrinters(win32print.PRINTER_ENUM_LOCAL | win32print.PRINTER_ENUM_CONNECTIONS)})
    except Exception:
        pass
    flags=getattr(subprocess,"CREATE_NO_WINDOW",0)
    for cmd in (
        ["powershell","-NoProfile","-Command","Get-CimInstance Win32_Printer | ForEach-Object {$_.Name}"],
        ["powershell","-NoProfile","-Command","Get-Printer | ForEach-Object {$_.Name}"]
    ):
        try:
            out=subprocess.check_output(cmd,text=True,encoding="utf-8",errors="ignore",timeout=5,creationflags=flags)
            names=sorted({x.strip() for x in out.splitlines() if x.strip()})
            if names:return names
        except Exception:pass
    return []

def safe(v):return re.sub(r"[^A-Za-z0-9._-]+","_",str(v or "LABEL"))[:80]
def pdf_printer(name):return "MICROSOFT PRINT TO PDF" in str(name or "").upper()
def save_pdf(img,path,wmm,hmm):
    doc=fitz.open();page=doc.new_page(width=wmm*72/25.4,height=hmm*72/25.4);b=io.BytesIO();img.convert("RGB").save(b,"PNG",dpi=(300,300));page.insert_image(page.rect,stream=b.getvalue(),keep_proportion=True);doc.save(path);doc.close()

def get_printer_dimensions_mm(name):
    if not name: return None, None
    try:
        import win32ui
        dc = win32ui.CreateDC()
        dc.CreatePrinterDC(name)
        pw = dc.GetDeviceCaps(8)
        ph = dc.GetDeviceCaps(10)
        dx = dc.GetDeviceCaps(88)
        dy = dc.GetDeviceCaps(90)
        dc.DeleteDC()
        if pw > 0 and ph > 0 and dx > 0 and dy > 0:
            w = round(pw * 25.4 / dx, 1)
            h = round(ph * 25.4 / dy, 1)
            if 10.0 <= w <= 500.0 and 10.0 <= h <= 500.0:
                return w, h
    except Exception:
        pass
    try:
        import win32print
        h = win32print.OpenPrinter(name)
        try:
            info = win32print.GetPrinter(h, 2)
            dm = info.get("pDevMode")
            if dm and getattr(dm, "PaperWidth", 0) > 0 and getattr(dm, "PaperLength", 0) > 0:
                w = round(dm.PaperWidth / 10.0, 1)
                h = round(dm.PaperLength / 10.0, 1)
                if 10.0 <= w <= 500.0 and 10.0 <= h <= 500.0:
                    return w, h
        finally:
            win32print.ClosePrinter(h)
    except Exception:
        pass
    return None, None

def output_image(img,printer,job,wmm,hmm):
    all_p = printers()
    if not printer or printer not in all_p:
        printer = default_printer()
    if not printer: raise RuntimeError("Is station par printer select nahi hua. Default printer check karein.")
    if pdf_printer(printer):
        path=OUT/f"{datetime.now():%Y%m%d_%H%M%S_%f}_{safe(job)}.pdf";save_pdf(img,path,wmm,hmm);return path.name
    if any(x in printer.upper() for x in ("XPS","ONENOTE","FAX")):raise RuntimeError("Unsupported virtual printer selected")
    
    # Direct TSPL high-speed thermal printing for TSC printers
    p_up = printer.upper()
    if any(k in p_up for k in ["TSC", "TE244", "DA310", "DA210"]):
        try:
            dpi = 300 if ("310" in p_up or "DA3" in p_up) else 203
            w_dots = int(round(wmm * dpi / 25.4))
            h_dots = int(round(hmm * dpi / 25.4))
            w_bytes = (w_dots + 7) // 8
            w_dots = w_bytes * 8
            im = img.convert("L") if img.mode != "L" else img
            if im.size != (w_dots, h_dots):
                im = im.resize((w_dots, h_dots), Image.Resampling.BILINEAR)
            # TSPL BITMAP standard polarity: 1 = unheated white paper, 0 = heated black dot
            bw = im.point(lambda x: 0 if x < 160 else 255, "1")
            raw_bytes = bw.tobytes()
            header = f"SIZE {wmm:0.1f} mm, {hmm:0.1f} mm\r\nGAP 3 mm, 0 mm\r\nDIRECTION 1\r\nCLS\r\nBITMAP 0,0,{w_bytes},{h_dots},0,".encode("latin1")
            footer = b"\r\nPRINT 1,1\r\n"
            payload = header + raw_bytes + footer
            sent = False
            try:
                import win32print
                hP = win32print.OpenPrinter(printer)
                try:
                    win32print.StartDocPrinter(hP, 1, (safe(job), None, "RAW"))
                    win32print.StartPagePrinter(hP)
                    win32print.WritePrinter(hP, payload)
                    win32print.EndPagePrinter(hP)
                    win32print.EndDocPrinter(hP)
                    sent = True
                finally:
                    win32print.ClosePrinter(hP)
            except Exception:
                sent = False
            if not sent:
                try:
                    import win32file
                    usb_p = r"\\?\USB#VID_1203&PID_0272#000001#{28d78fad-5a12-11d1-ae5b-0000f803a8c2}" if "244" in p_up else r"\\?\USB#VID_1203&PID_0253#000001#{28d78fad-5a12-11d1-ae5b-0000f803a8c2}"
                    hU = win32file.CreateFile(usb_p, win32file.GENERIC_READ | win32file.GENERIC_WRITE, win32file.FILE_SHARE_READ | win32file.FILE_SHARE_WRITE, None, win32file.OPEN_EXISTING, 0, 0)
                    win32file.WriteFile(hU, payload)
                    win32file.CloseHandle(hU)
                    sent = True
                except Exception:
                    pass
            if sent:
                return printer
        except Exception:
            pass

    class DOCINFOW(ctypes.Structure):
        _fields_=[("cbSize",ctypes.c_int),("lpszDocName",wintypes.LPCWSTR),("lpszOutput",wintypes.LPCWSTR),("lpszDatatype",wintypes.LPCWSTR),("fwType",wintypes.DWORD)]
    gdi=ctypes.windll.gdi32
    gdi.CreateDCW.argtypes=[wintypes.LPCWSTR,wintypes.LPCWSTR,wintypes.LPCWSTR,ctypes.c_void_p]
    gdi.CreateDCW.restype=wintypes.HDC
    gdi.GetDeviceCaps.argtypes=[wintypes.HDC,ctypes.c_int]
    gdi.StartDocW.argtypes=[wintypes.HDC,ctypes.POINTER(DOCINFOW)]
    gdi.StartPage.argtypes=[wintypes.HDC];gdi.EndPage.argtypes=[wintypes.HDC]
    gdi.EndDoc.argtypes=[wintypes.HDC];gdi.AbortDoc.argtypes=[wintypes.HDC]
    gdi.DeleteDC.argtypes=[wintypes.HDC]
    hdc=gdi.CreateDCW("WINSPOOL",printer,None,None)
    if not hdc:raise ctypes.WinError()
    pw,ph=gdi.GetDeviceCaps(hdc,8),gdi.GetDeviceCaps(hdc,10);dx,dy=gdi.GetDeviceCaps(hdc,88),gdi.GetDeviceCaps(hdc,90)
    tw,th=int(round(wmm*dx/25.4)),int(round(hmm*dy/25.4))
    if pw>0 and tw>pw: tw=pw
    if ph>0 and th>ph: th=ph
    x,y=0,0
    doc=DOCINFOW(ctypes.sizeof(DOCINFOW),str(job),None,None,0)
    started=False
    try:
        if gdi.StartDocW(hdc,ctypes.byref(doc))<=0:raise ctypes.WinError()
        started=True
        if gdi.StartPage(hdc)<=0:raise ctypes.WinError()
        ImageWin.Dib(img.convert("RGB")).draw(hdc,(x,y,x+tw,y+th))
        if gdi.EndPage(hdc)<=0:raise ctypes.WinError()
        if gdi.EndDoc(hdc)<=0:raise ctypes.WinError()
        started=False
    except:
        if started:gdi.AbortDoc(hdc)
        raise
    finally:gdi.DeleteDC(hdc)
    return printer

def request(url,data=None):
    body=urllib.parse.urlencode(data).encode() if data is not None else None
    h={"X-Agent-Version":AGENT_VERSION}
    if body: h["Content-Type"]="application/x-www-form-urlencoded"
    req=urllib.request.Request(url,data=body,headers=h)
    with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(req,timeout=60) as r:return r.read(),dict(r.headers)

def do_job(data):
    server=str(data["server"]).rstrip("/");oid=int(data["oid"]);station=str(data["station"]);cfg=config();outputs=[]
    all_p=printers()
    dp=default_printer()
    mrp_p=cfg.get("mrp_printer")
    ship_p=cfg.get("shipping_printer")
    if not mrp_p or mrp_p not in all_p:
        mrp_p = next((p for p in all_p if "244" in p.upper()), None) or next((p for p in all_p if "TSC" in p.upper() and "310" not in p.upper()), dp)
    if not ship_p or ship_p not in all_p:
        ship_p = next((p for p in all_p if "310" in p.upper()), None) or next((p for p in all_p if "DA" in p.upper() or "SHIP" in p.upper()), dp)
    mrp_w=float(cfg.get("mrp_width_mm") or 100.0)
    mrp_h=float(cfg.get("mrp_height_mm") or 50.0)
    ship_w=float(cfg.get("shipping_width_mm") or 100.0)
    ship_h=float(cfg.get("shipping_height_mm") or 150.0)
    scan_mode=str(data.get("scan_mode") or "").upper()
    # Requirement: For ALL orders (combo or regular), both MRP barcode and shipping slip must print at least 1 time!
    is_mrp = True
    is_shipping = True
    with PRINT_LOCK:
        try:
            for kind,required,printer,w,h in (
                ("MRP",is_mrp,mrp_p,mrp_w,mrp_h),
                ("SHIPPING",is_shipping,ship_p,ship_w,ship_h)
            ):
                if not required:continue
                try:
                    url=f"{server}/api/local-print-asset/{oid}/{kind}?"+urllib.parse.urlencode({"station":station})
                    raw,_=request(url);img=Image.open(io.BytesIO(raw));outputs.append(output_image(img,printer,f"{kind}_{data.get('order_id',oid)}",w,h))
                except Exception as ex_label:
                    print(f"[{kind}] print warning for order {oid}: {ex_label}")
            raw,_=request(f"{server}/api/confirm-local-print/{oid}",{
                "station":station,
                "files":"|".join(outputs),
                "printed_mrp":"YES" if is_mrp else "NO",
                "printed_shipping":"YES" if is_shipping else "NO",
                "scan_token":data.get("scan_token","")
            })
            result=json.loads(raw.decode());result["local_outputs"]=outputs;return result
        except Exception as e:
            try:request(f"{server}/api/cancel-local-print/{oid}",{"station":station,"message":str(e),"scan_token":data.get("scan_token","")})
            except:pass
            raise

def do_reprint(data):
    server=str(data["server"]).rstrip("/");oid=int(data["oid"]);cfg=config();outputs=[]
    all_p=printers()
    dp=default_printer()
    mrp_p=cfg.get("mrp_printer")
    ship_p=cfg.get("shipping_printer")
    if not mrp_p or mrp_p not in all_p:
        mrp_p = next((p for p in all_p if "244" in p.upper()), None) or next((p for p in all_p if "TSC" in p.upper() and "310" not in p.upper()), dp)
    if not ship_p or ship_p not in all_p:
        ship_p = next((p for p in all_p if "310" in p.upper()), None) or next((p for p in all_p if "DA" in p.upper() or "SHIP" in p.upper()), dp)
    mrp_w=float(cfg.get("mrp_width_mm") or 100.0)
    mrp_h=float(cfg.get("mrp_height_mm") or 50.0)
    ship_w=float(cfg.get("shipping_width_mm") or 100.0)
    ship_h=float(cfg.get("shipping_height_mm") or 150.0)
    raw,_=request(f"{server}/api/local-reprint-manifest/{oid}");manifest=json.loads(raw.decode())
    req_mrp = True  # MRP barcode to nikalvo j joye!
    req_ship = True  # Shipping slip to nikalvi j joye!
    with PRINT_LOCK:
        for kind,required,printer,w,h in (
            ("MRP",req_mrp,mrp_p,mrp_w,mrp_h),
            ("SHIPPING",req_ship,ship_p,ship_w,ship_h)
        ):
            if not required:continue
            try:
                raw,_=request(f"{server}/api/local-reprint-asset/{oid}/{kind}");img=Image.open(io.BytesIO(raw));outputs.append(output_image(img,printer,f"REPRINT_{kind}_{manifest.get('order_id',oid)}",w,h))
            except Exception as ex_rep:
                print(f"[REPRINT {kind}] warning for {oid}: {ex_rep}")
    return {"ok":True,"local_outputs":outputs}

def save_bulk_files(data):
    server=str(data["server"]).rstrip("/");saved=[]
    for name in data.get("files",[]):
        filename=Path(str(name)).name;raw,_=request(f"{server}/api/output/"+urllib.parse.quote(filename));target=OUT/filename;target.write_bytes(raw);saved.append(filename)
    return {"ok":True,"local_outputs":saved,"output_folder":str(OUT)}

class Handler(BaseHTTPRequestHandler):
    def log_message(self,fmt,*args):pass
    def cors(self):
        self.send_header("Access-Control-Allow-Origin","*")
        self.send_header("Access-Control-Allow-Methods","GET,POST,OPTIONS")
        self.send_header("Access-Control-Allow-Headers","*")
        self.send_header("Access-Control-Allow-Private-Network","true")
    def reply(self,status,obj):
        raw=json.dumps(obj).encode()
        self.send_response(status)
        self.cors()
        self.send_header("Content-Type","application/json")
        self.send_header("Content-Length",str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)
    def do_OPTIONS(self):
        self.send_response(204)
        self.cors()
        self.end_headers()
    def do_GET(self):
        if self.path.startswith("/health"):
            dp = default_printer()
            self.reply(200,{"ok":True,"app":"OSLC_PACK_STATION_AGENT","version":AGENT_VERSION,"printers":printers(),"default_printer":dp,"config":config(),"output_folder":str(OUT)})
            return
        self.reply(404,{"detail":"Not found"})
    def do_POST(self):
        try:
            n=int(self.headers.get("Content-Length","0"));data=json.loads(self.rfile.read(n) or b"{}")
            if self.path.startswith("/settings"):self.reply(200,{"ok":True,"config":save_config(data)});return
            if self.path.startswith("/reprint"):self.reply(200,do_reprint(data));return
            if self.path.startswith("/save-files"):self.reply(200,save_bulk_files(data));return
            if self.path.startswith("/print"):self.reply(200,do_job(data));return
            self.reply(404,{"detail":"Not found"})
        except Exception as e:self.reply(400,{"detail":str(e)})

if __name__=="__main__":
    print("\nOSLC LOCAL PRINT AGENT IS READY")
    print("Default printer:", default_printer())
    print("Local PDF folder:", OUT, "\n")
    ThreadingHTTPServer(("127.0.0.1",8790),Handler).serve_forever()
