@echo off
title Setup OSLC Pack Station PC
cd /d "%~dp0"

echo ========================================================
echo        SETTING UP OSLC PACK STATION ON THIS PC
echo ========================================================
echo.

set "STATION_PYTHON="
for /f "delims=" %%P in ('py -3 -c "import sys;print(sys.executable)" 2^>nul') do set "STATION_PYTHON=%%P"
if not defined STATION_PYTHON for /f "delims=" %%P in ('python -c "import sys;print(sys.executable)" 2^>nul') do set "STATION_PYTHON=%%P"

if not defined STATION_PYTHON (
  echo Python is not installed on this PC.
  echo Downloading and installing Python automatically...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -UseBasicParsing 'https://www.python.org/ftp/python/3.12.10/python-3.12.10-amd64.exe' -OutFile '%TEMP%\oslc_py_setup.exe'"
  if exist "%TEMP%\oslc_py_setup.exe" (
    start /wait "" "%TEMP%\oslc_py_setup.exe" /quiet InstallAllUsers=0 TargetDir="%LocalAppData%\Programs\OSLCPython" Include_pip=1 PrependPath=1 Shortcuts=0
    if exist "%LocalAppData%\Programs\OSLCPython\python.exe" set "STATION_PYTHON=%LocalAppData%\Programs\OSLCPython\python.exe"
    del /q "%TEMP%\oslc_py_setup.exe" >nul 2>&1
  )
)

if not defined STATION_PYTHON (
  echo Python could not be installed automatically. Please install Python from python.org.
  pause
  exit /b 1
)

echo Installing printer drivers support (Pillow, PyMuPDF)...
"%STATION_PYTHON%" -m pip install --upgrade Pillow PyMuPDF >nul 2>&1

echo Creating Desktop Shortcut...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$WshShell = New-Object -ComObject WScript.Shell; " ^
  "$Desktop = [Environment]::GetFolderPath('Desktop'); " ^
  "$Shortcut = $WshShell.CreateShortcut((Join-Path $Desktop 'OSLC Pack Station.lnk')); " ^
  "$Shortcut.TargetPath = 'wscript.exe'; " ^
  "$Shortcut.Arguments = '\"\"%~dp0START_STATION.vbs\"\"'; " ^
  "$Shortcut.WorkingDirectory = '%~dp0'; " ^
  "$Shortcut.IconLocation = '%~dp0oslc_icon.ico,0'; " ^
  "$Shortcut.Description = 'OSLC Pack Station Client'; " ^
  "$Shortcut.Save();"

echo.
echo ========================================================
echo   STATION SETUP COMPLETE!
echo   A shortcut 'OSLC Pack Station' is on your Desktop.
echo   Just double-click it to start packing and printing!
echo ========================================================
echo.
pause
