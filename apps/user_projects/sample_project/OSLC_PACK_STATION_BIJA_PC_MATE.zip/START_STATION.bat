@echo off
title OSLC Pack Station
cd /d "%~dp0"

rem 1. Read Server URL
set "SERVER_URL=http://192.168.100.126:8787"
if exist "server_url.txt" (
  set /p SERVER_URL=<server_url.txt
)

rem 2. Check if Print Agent is already running on port 8790
powershell -NoProfile -ExecutionPolicy Bypass -Command "try { $r=Invoke-WebRequest -UseBasicParsing 'http://127.0.0.1:8790/health' -TimeoutSec 1; if ($r.StatusCode -eq 200) { exit 0 } } catch {}; exit 1" >nul 2>&1
if not errorlevel 1 (
  start "" "%SERVER_URL%"
  exit /b 0
)

rem 3. Find Python
set "STATION_PYTHON="
for /f "delims=" %%P in ('py -3 -c "import sys;print(sys.executable)" 2^>nul') do set "STATION_PYTHON=%%P"
if not defined STATION_PYTHON for /f "delims=" %%P in ('python -c "import sys;print(sys.executable)" 2^>nul') do set "STATION_PYTHON=%%P"

if not defined STATION_PYTHON (
  echo Python not found on this pack station. Please run SETUP_STATION.bat first.
  pause
  exit /b 1
)

rem 4. Start Local Print Agent in background
start "" "%STATION_PYTHON%" PACK_STATION_AGENT.py
timeout /t 1 /nobreak >nul

rem 5. Open Server in browser
start "" "%SERVER_URL%"
exit /b 0
